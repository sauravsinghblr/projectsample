package com.sample

import java.util.Properties

import scala.language.implicitConversions
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.expressions.Substring
import org.apache.spark.sql.{DataFrame, SparkSession}


import scala.io.Source

object project1 extends Serializable {
  @transient lazy val logger: Logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    if (args.length == 0) {
      logger.error("Usage: Project1 filename")
      System.exit(1)
    }

    logger.info("Starting Project1")
    val spark = SparkSession.builder()
      .config(getSparkAppConf)
      .getOrCreate()
    import spark.implicits._
    val barleyUSADF = loadDF(spark, args(0)).withColumn("year",($"crop year").substr(0,5)).withColumnRenamed("Yield","Barley_usa_yield").select("year","Barley_usa_yield")
    val barleyworldDF = loadDF(spark, args(1)).withColumn("year",($"crop year").substr(0,5)).withColumnRenamed("Yield","Barley_world_yield").select("year","Barley_world_yield")
    val beefUSADF = loadDF(spark, args(2)).withColumnRenamed("Calendar year","year").withColumnRenamed("Production","Production_beef_usa").select("year","Production_beef_usa")
    val beefworldDF = loadDF(spark, args(3)).withColumnRenamed("Calendar year","year").withColumnRenamed("Production","Production_beef_world").select("year","Production_beef_world")

    val join_result = barleyUSADF.join(barleyworldDF, "year").join(beefUSADF, "year").join(beefworldDF,"year")
    val result_temp = join_result.withColumn("barley_usa_contribution%",(($"Barley_usa_yield"/$"Barley_world_yield")*100)).withColumn("beef_usa_contribution%",(($"Production_beef_usa"/$"Production_beef_world")*100))

    val result = result_temp.select("year","Barley_usa_yield","Barley_world_yield","barley_usa_contribution%","Production_beef_usa","Production_beef_world","beef_usa_contribution%")
    result.show()

  }

  def loadDF(spark: SparkSession, dataFile: String): DataFrame = {
    spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(dataFile)
  }

  def getSparkAppConf: SparkConf = {
    val sparkAppConf = new SparkConf
    //Set all Spark Configs
    val props = new Properties
    props.load(Source.fromFile("spark.conf").bufferedReader())
    props.forEach((k, v) => sparkAppConf.set(k.toString, v.toString))
    sparkAppConf
  }
}
